import pandas as pd

# 读取CSV文件
df = pd.read_csv('../import.csv', skiprows=14)

# 圈速
sector_lap_times = pd.DataFrame(columns=['Lap', 'Sector', 'Time'])

current_lap = 1
for index, row in df.iterrows():
    data = str(row.iloc[0])
    if data.startswith('# Sector'):
        # Sector 6: 00:00:22.252
        # print(data)
        current_sector = int(data.split(': ')[0].split(' ')[2])
        current_time = data.split(': ')[1]
        sector_lap_times = pd.concat([sector_lap_times, pd.DataFrame({'Lap': [current_lap], 'Sector': [current_sector], 'Time': [current_time]})], ignore_index=True)

    elif data.startswith('# Lap'):
        # Lap 5: 00:02:21.426
        current_lap = int(data.split(': ')[0].split(' ')[2]) + 1
        if current_lap == 1:
            continue
        # print("Lap:", current_lap)
        # print("----------------")
        
# print(sector_lap_times)

# 计算每个Sector中哪个Lap用时最短
shortest_lap_times = sector_lap_times.groupby('Sector')['Time'].min()

for sector, time in shortest_lap_times.items():
    print(f'第 {sector} 段用时最短的为第 {sector_lap_times[(sector_lap_times["Sector"] == sector) & (sector_lap_times["Time"] == time)]["Lap"].values[0]} 圈, 用时{time}')
