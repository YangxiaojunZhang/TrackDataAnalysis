import pandas as pd

import folium
from folium import plugins

# 读取CSV文件
df = pd.read_csv('../import.csv', comment='#')

filtered_df = df[df['GPS_Update'] == 1]

# 构造新的DataFrame
location_df = pd.DataFrame(columns=['Time', 'Lap', 'Sector', 'Latitude', 'Longitude'])
location_df['Time'] = filtered_df['Time']
location_df['Lap'] = filtered_df['Lap']
location_df['Sector'] = filtered_df['Sector']
location_df['Latitude'] = filtered_df['Latitude']
location_df['Longitude'] = filtered_df['Longitude']

print(location_df)

# 创建地图
m = folium.Map(location=[location_df['Latitude'].mean(), location_df['Longitude'].mean()], zoom_start=16)

# 根据不同的Lap创建不同的颜色
colors = ['red', 'blue', 'green', 'purple', 'orange', 'darkred', 'lightred', 'beige', 'darkblue', 'darkgreen']

for lap in location_df['Lap'].unique():
    lap_df = location_df[location_df['Lap'] == lap]
    lap_points = list(zip(lap_df['Latitude'], lap_df['Longitude']))
    
    folium.PolyLine(locations=lap_points, color=colors[lap % len(colors)], weight=2.5, opacity=1).add_to(m)

# 保存地图
m.save('path_map.html')