from PyQt5.QtWidgets import QDesktopWidget, QFileDialog, QMessageBox
from PyQt5 import uic, QtWebEngineWidgets

from ComboCheckBox import ComboCheckBox

import pandas as pd
import folium
import traceback

class MainWindow():
    def __init__(self):
        self.ui = uic.loadUi('ui/window.ui')

        screen = QDesktopWidget().screenGeometry()
        screen_center = screen.center()
        window_position = screen_center - self.ui.rect().center()
        self.ui.move(window_position)

        self.ui.importButton.clicked.connect(self.loadData)
        self.ui.filterButton.clicked.connect(self.filterLap)

        self.ui.comboBox = ComboCheckBox()
        self.ui.comboBox.loadItems(["1"])
        self.ui.controlPanelLayout.addWidget(self.ui.comboBox)


    def loadData(self):
        try:
            file_path, _ = QFileDialog.getOpenFileName(self.ui, "导入数据", "", "CSV Files (*.csv)")
            if file_path:

                # 读取文本文件，跳过以#开头的行
                skip_lines = 0
                with open(file_path, 'r') as file:
                    for line in file:
                        if line.strip().startswith("#"):
                            skip_lines += 1
                        else:
                            break

                # =======
                # 圈速部分
                df = pd.read_csv(file_path, skiprows=skip_lines)
                sector_lap_times = pd.DataFrame(columns=['Lap', 'Sector', 'Time'])

                current_lap = 1
                for index, row in df.iterrows():
                    data = str(row.iloc[0])
                    if data.startswith('# Sector'):
                        current_sector = int(data.split(': ')[0].split(' ')[2])
                        current_time = data.split(': ')[1]
                        sector_lap_times = pd.concat([sector_lap_times, pd.DataFrame({'Lap': [current_lap], 'Sector': [current_sector], 'Time': [current_time]})], ignore_index=True)

                    elif data.startswith('# Lap'):
                        current_lap = int(data.split(': ')[0].split(' ')[2]) + 1
                        if current_lap == 1:
                            continue

                # 计算每个Sector中哪个Lap用时最短
                shortest_lap_times = sector_lap_times.groupby('Sector')['Time'].min()

                text = ''
                for sector, time in shortest_lap_times.items():
                    text = text + f'The fastest section {sector} is in lap {sector_lap_times[(sector_lap_times["Sector"] == sector) & (sector_lap_times["Time"] == time)]["Lap"].values[0]}, uses {time}\n'
                text = text[:-1]
                self.ui.textDisplay.setText(text)
                # ======
                # 地图部分
                df = pd.read_csv(file_path, comment='#')

                filtered_df = df[df['GPS_Update'] == 1]

                # 构造新的DataFrame
                self.location_df = pd.DataFrame(columns=['Time', 'Lap', 'Sector', 'Latitude', 'Longitude'])
                self.location_df['Time'] = filtered_df['Time']
                self.location_df['Lap'] = filtered_df['Lap']
                # self.location_df['Sector'] = filtered_df['Sector']
                self.location_df['Latitude'] = filtered_df['Latitude']
                self.location_df['Longitude'] = filtered_df['Longitude']

                self.ui.comboBox.loadItems(self.location_df['Lap'].unique().tolist())
                self.ui.comboBox.All(2)
                self.updateMap(self.location_df['Lap'].unique())

        except Exception:
            traceback.print_exc()
            self.error_message("Error", "Import error!")
            return
        
    def filterLap(self):
        self.updateMap(self.ui.comboBox.currentText())

    def updateMap(self, laps):
        if not hasattr(self, 'location_df'):
            return

        try:
            laps = [int(lap) for lap in laps]
        except Exception:
            traceback.print_exc()
            self.error_message("Error", "Data error!")
            return
        
        # 创建地图
        m = folium.Map(location=[self.location_df['Latitude'].mean(), self.location_df['Longitude'].mean()], zoom_start=15)
        # colors = ['red', 'blue', 'green', 'purple', 'orange', 'darkred', 'lightred', 'beige', 'darkblue', 'darkgreen']
        colors = ['#e41a1c','#377eb8','#4daf4a','#984ea3','#ff7f00','#ffff33','#a65628','#f781bf']

        for lap in laps:
            lap_df = self.location_df[self.location_df['Lap'] == lap]
            lap_points = list(zip(lap_df['Latitude'], lap_df['Longitude']))
            
            folium.PolyLine(locations=lap_points, color=colors[lap % len(colors)], weight=2.5, opacity=1).add_to(m)
        webView = QtWebEngineWidgets.QWebEngineView()
        webView.setHtml(m.get_root().render())
        
        layout = self.ui.mapBox
        item = layout.itemAt(0)
        layout.removeItem(item)
        layout.addWidget(webView)

    def error_message(self, title, text):
        error_message = QMessageBox()
        error_message.setIcon(QMessageBox.Critical)
        error_message.setText(text)
        error_message.setWindowTitle(title)
        error_message.exec_()

