import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QLabel, QLineEdit, QVBoxLayout, QHBoxLayout, QTabWidget, QCheckBox
from PyQt5 import QtCore

# import qdarkstyle
from window import MainWindow

if __name__ == '__main__':
    app = QApplication(sys.argv)

    app.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling)  # 适应高分辨率
    # qdarkstyle
    # app.setStyleSheet(qdarkstyle.load_stylesheet())

    font = app.font()
    font.setFamily("Microsoft YaHei, SimSun, SimSun-ExtB")
    # font.setFamily("Times New Roman, Microsoft YaHei, SimSun, SimSun-ExtB")
    app.setFont(font)

    mainWindow = MainWindow()
    mainWindow.ui.show()

    sys.exit(app.exec_())